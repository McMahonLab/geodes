mkdir -p result
sh test_minimal_example.sh
sh test_chr_aliases.sh
sh test_chr_inference.sh
sh test_corner_cases.sh
sh test_featurelevel.sh
